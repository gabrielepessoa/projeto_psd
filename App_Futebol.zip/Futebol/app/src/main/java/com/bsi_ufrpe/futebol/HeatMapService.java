package com.bsi_ufrpe.futebol;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class HeatMapService {

    public static String getPositions() {
        Log.e("webservice", "chamada ao webservice");
        String resultado = "";
        try {
            String IP = HeatMapBusiness.getIP();
            //192.168.25.25
            URL url = new URL("http://"+IP+":5000/time_a/Dennis_Dotterweich/");
            Log.e("webservice", IP);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            Log.e("webservice", "passou aqui 01!");
            InputStream buffer = new BufferedInputStream(connection.getInputStream());
            //String inputStream = connection..getContentEncoding();
            Log.e("webservice", "passou aqui 02!");

            resultado = convertToString(buffer);
            connection.disconnect();
            Log.e("webservice", "dicionário do jogador: "+resultado);
        } catch (Exception e){
            Log.e("webservice", e.getMessage().toString());
            e.printStackTrace();
        }
        return resultado.replace(" ","").replace("{","").replace("}","");
        //return "'1:2':7,'1:5':25,'5:3':15,'7:5':7";
    }

    public static String convertToString(InputStream in){
        BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
        StringBuilder builder = new StringBuilder();
        String linha = null;
        try {
            while ((linha = buffer.readLine()) != null){
                builder.append(linha);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        Log.i("Retorno webservice:", builder.toString());

        return builder.toString();
    }

}
