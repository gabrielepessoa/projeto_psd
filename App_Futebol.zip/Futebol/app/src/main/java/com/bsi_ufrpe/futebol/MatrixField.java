package com.bsi_ufrpe.futebol;

public class MatrixField {
    private int[][] matrix = new int[9][14];

    public MatrixField(){
        for (int i = 0; i < matrix.length; i++){
            for (int j = 0; j < matrix[i].length; j++){
                matrix[i][j] = 0;
            }
        }
    }

    public int[][] getMatrix() {
        return matrix;
    }

    public int getPositionQtd(int i, int j){
        return matrix[i+1][j+1];
    }

    public void insertMatrix(int i, int j, int qtd) {
        this.matrix[i][j] = qtd;
    }




}
