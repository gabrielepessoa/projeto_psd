package com.bsi_ufrpe.futebol;

public class HeatMapBusiness {
    private static int teamSelected;
    private static int playerSelected;
    private static String IP;

    public static int getTeamSelected() {
        return teamSelected;
    }

    public static void setTeamSelected(int teamSelected) {
        HeatMapBusiness.teamSelected = teamSelected;
    }

    public static int getPlayerSelected() {
        return playerSelected;
    }

    public static void setPlayerSelected(int playerSelected) {
        HeatMapBusiness.playerSelected = playerSelected;
    }

    public static MatrixField refreshField(){
        //getTeamSelected();
        //getPlayerSelected();
        MatrixField matrixField = new MatrixField();

        String response = HeatMapService.getPositions();
        if (response != "") {
            String[] positions = response.split(",");
            for (String position : positions) {
                String[] values = position.replace("'", "").split(":");
                matrixField.insertMatrix(Integer.valueOf(values[0]),
                        Integer.valueOf(values[1]),
                        Integer.valueOf(values[2]));
            }
        }
        return matrixField;
    }

    public static void setIP(String newIP){
        IP = newIP;
    }

    public static String getIP(){
        return IP;
    }
}
