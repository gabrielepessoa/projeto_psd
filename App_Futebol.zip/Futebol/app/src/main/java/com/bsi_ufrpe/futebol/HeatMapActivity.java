package com.bsi_ufrpe.futebol;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class HeatMapActivity extends AppCompatActivity {
    private AlertDialog alert;
    private MatrixField matrixField;
    private LinearLayout matrixLayout;
    private ProgressDialog load;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.heat_map_activity);

        matrixLayout = (LinearLayout) findViewById(R.id.matrix);
    }

    public void alertTeam() {
        String[] teamsNames = new String[]{"Time A", "Time B"};
        List<String> teams = Arrays.asList(teamsNames);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, teams);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Times");
        builder.setNegativeButton("Voltar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                alert.dismiss();
            }
        });
        // Define o Dialog como uma lista, passa o adapter
        builder.setSingleChoiceItems(adapter, 0, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int position) {
                Toast.makeText(HeatMapActivity.this, "posição selecionada = " + position, Toast.LENGTH_SHORT).show();
                changeTeam(position);
                alert.dismiss();
            }
        });
        alert = builder.create();
        alert.show();
    }

    private void changeTeam(int idNewTeamSelected) {
        HeatMapBusiness.setTeamSelected(idNewTeamSelected);
        //refreshHeatMap();
    }

    public void alertPlayer() {
        String[] playersNames = new String[]{"Jogador 1", "Jogador 2", "Jogador 3", "Jogador 4", "Jogador 5", "Jogador 6", "Jogador 7", "Jogador 8"};
        List<String> players = Arrays.asList(playersNames);

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, players);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Jogadores");
        builder.setNegativeButton("Voltar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                alert.dismiss();
            }
        });
        // Define o Dialog como uma lista, passa o adapter
        builder.setSingleChoiceItems(adapter, 0, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int position) {
                Toast.makeText(HeatMapActivity.this, "posição selecionada = " + position, Toast.LENGTH_SHORT).show();
                changePlayer(position);
                alert.dismiss();
            }
        });
        alert = builder.create();
        alert.show();
    }

    private void changePlayer(int idNewPlayerSelected) {
        HeatMapBusiness.setPlayerSelected(idNewPlayerSelected);
        //refreshHeatMap();
    }

    private void refreshHeatMap() {
        //matrixField = HeatMapBusiness.refreshField();
        try {
            chamarAsyncTask();
            //buildHeatMap();
        } catch (Exception ex){
            Log.e("webservice", ex.getMessage().toString());
        }
    }

    private void buildHeatMap() {
        for (int i = 0; i < matrixLayout.getChildCount(); i++) {
            LinearLayout row = (LinearLayout) matrixLayout.getChildAt(i);
            for (int j = 0; j < row.getChildCount(); j++) {
                LinearLayout square = (LinearLayout) row.getChildAt(j);
                int qtd = matrixField.getPositionQtd(i, j);
                int color = this.chooseColor(qtd);
                square.setBackgroundColor(getResources().getColor(color));
            }
        }
    }

    private int chooseColor(int qtd) {
        if (qtd == 0) {
            return R.color.greenField2;
        } else if (qtd > 0 && qtd <= 10) {
            return R.color.greenLight;
        } else if (qtd > 10 && qtd <= 30) {
            return R.color.yellowLight;
        } else if (qtd > 30 && qtd <= 60) {
            return R.color.yellowDark;
        } else if (qtd > 60 && qtd <= 100) {
            return R.color.redLight;
        } else if (qtd > 100) {
            return R.color.redDark;
        } else {
            return R.color.greenField2;
        }
    }

    private void chamarAsyncTask() {
        TarefaDownload download = new TarefaDownload();
        Log.i("AsyncTask", "AsyncTask sendo chamada. Thread: " + Thread.currentThread().getName());
        download.execute();
    }

    private class TarefaDownload extends AsyncTask<Void, Void, MatrixField> {
        @Override
        protected void onPreExecute() {
            Log.i("AsyncTask", "Exibindo ProgressDialog na tela. Thread: " + Thread.currentThread().getName());
            load = ProgressDialog.show(HeatMapActivity.this, "Por favor, aguarde ...",
                    "Carregando posições ...");
        }

        @Override
        protected MatrixField doInBackground(Void... params) {
            Log.i("AsyncTask", "Requisição ao webservice. Thread: " + Thread.currentThread().getName());
            return HeatMapBusiness.refreshField();
        }

        @Override
        protected void onPostExecute(MatrixField mtx) {
            matrixField = mtx;
            buildHeatMap();
            Log.i("AsyncTask", "Tirando ProgressDialog da tela. Thread: " + Thread.currentThread().getName());
            load.dismiss();
        }
    }

    // - - - - - - - - - - - - - - AÇÕES DO MENU - - - - - - - - - - - - - - //
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_team:
                alertTeam();
                return true;
            case R.id.action_player:
                alertPlayer();
                return true;
            case R.id.action_refresh:
                refreshHeatMap();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
