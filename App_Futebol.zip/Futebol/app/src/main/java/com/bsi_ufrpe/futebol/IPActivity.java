package com.bsi_ufrpe.futebol;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class IPActivity extends AppCompatActivity {
    private EditText edtIP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ip);

        edtIP = (EditText) findViewById(R.id.edtIP);
    }

    public void setIP(View view){
        String ip = edtIP.getText().toString();
        HeatMapBusiness.setIP(ip);
        Intent intent = new Intent(IPActivity.this, HeatMapActivity.class);
        startActivity(intent);
        IPActivity.this.finish();
    }
}
